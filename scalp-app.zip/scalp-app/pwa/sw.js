const C='scalp-v1',F=['/','/manifest.json','/icon.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener('fetch',e=>{
  if(e.request.url.includes('/api/'))return; // données toujours en direct
  e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
});
