"""Backend du tableau de bord (étape 1 : lecture seule).
Sans METAAPI_TOKEN / METAAPI_ACCOUNT_ID, il tourne en mode DÉMO avec de fausses données."""
import os, random, time
from datetime import datetime, timezone
import httpx
from fastapi import FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles

TOKEN = os.getenv("METAAPI_TOKEN")
ACCOUNT = os.getenv("METAAPI_ACCOUNT_ID")
REGION = os.getenv("METAAPI_REGION", "new-york")
PIN = os.getenv("APP_PIN", "1234")  # À CHANGER
DEMO = not (TOKEN and ACCOUNT)
BASE = f"https://mt-client-api-v1.{REGION}.agiliumtrade.ai/users/current/accounts/{ACCOUNT}"

app = FastAPI()

def check(pin):
    if pin != PIN:
        raise HTTPException(401, "PIN invalide")

async def meta(path):
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(BASE + path, headers={"auth-token": TOKEN})
        r.raise_for_status()
        return r.json()

@app.get("/api/status")
async def status(x_pin: str = Header(None)):
    check(x_pin)
    if DEMO:
        bal = 25.0
        return {"demo": True, "balance": bal, "equity": round(bal + random.uniform(-0.6, 0.8), 2),
                "profit_today": round(random.uniform(-0.5, 1.2), 2), "positions": [
                    {"type": "BUY", "volume": 0.01, "open": 2650.4, "profit": round(random.uniform(-0.3, 0.5), 2)}]}
    info = await meta("/account-information")
    pos = await meta("/positions")
    start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    deals = await meta(f"/history-deals/time/{start.isoformat()}/{datetime.now(timezone.utc).isoformat()}")
    today = sum(d.get("profit", 0) for d in deals)
    return {"demo": False, "balance": info["balance"], "equity": info["equity"],
            "profit_today": round(today, 2),
            "positions": [{"type": p["type"].replace("POSITION_TYPE_", ""), "volume": p["volume"],
                           "open": p["openPrice"], "profit": p["profit"]} for p in pos]}

app.mount("/", StaticFiles(directory="pwa", html=True), name="pwa")
