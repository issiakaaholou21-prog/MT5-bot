# Scalp Dashboard (étape 1, lecture seule)

## Lancer en local (mode démo)
pip install -r requirements.txt
uvicorn main:app --reload
Ouvre http://localhost:8000 (PIN par défaut : 1234)

## Brancher ton compte (démo Exness d'abord)
1. Crée un compte sur metaapi.cloud, ajoute ton compte MT5 Exness (démo), note le token et l'ID du compte.
2. Variables d'environnement :
   METAAPI_TOKEN=...  METAAPI_ACCOUNT_ID=...  METAAPI_REGION=new-york  APP_PIN=ton_code
3. Vérifie les URLs/région dans la doc MetaApi si une erreur apparaît.

## Installer comme appli
Le PWA exige HTTPS : déploie sur Render, Railway ou un VPS, ouvre l'URL sur ton téléphone,
puis menu du navigateur > « Ajouter à l'écran d'accueil ».
